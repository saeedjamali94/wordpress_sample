<?php
/**
 * Understrap functions and definitions
 *
 * @package understrap
 */

/**
 * Initialize theme default settings
 */
add_theme_support('menus');
add_theme_support( 'post-thumbnails' );
require get_template_directory() . '/inc/theme-settings.php';

/**
 * Theme setup and custom theme supports.
 */
require get_template_directory() . '/inc/setup.php';

/**
 * Register widget area.
 */
require get_template_directory() . '/inc/widgets.php';

/**
 * Enqueue scripts and styles.
 */
require get_template_directory() . '/inc/enqueue.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/pagination.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Custom Comments file.
 */
require get_template_directory() . '/inc/custom-comments.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Load custom WordPress nav walker.
 */
require get_template_directory() . '/inc/bootstrap-wp-navwalker.php';

/**
 * Load WooCommerce functions.
 */
require get_template_directory() . '/inc/woocommerce.php';

/**
 * Load Editor functions.
 */
require get_template_directory() . '/inc/editor.php';


	
/* Convert English Numbers to Persian - By www.iliana.ir */
function iliana_adding_scripts() {
wp_register_script('persianumber', get_template_directory_uri() . '/js/persianumber.js', array('jquery'),'1.0', true);
wp_enqueue_script('persianumber');
}
 
add_action( 'wp_enqueue_scripts', 'iliana_adding_scripts' );
?>

<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'باکس یک',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>

<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'باکس دو',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>
<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'باکس سه',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>
<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'باکس چهار',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>

<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'متن اصلی سایت',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>

<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'باکس رنگی',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>

<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'باکس مزایا',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>

<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'آخرین مقالات',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>
<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'فوتر ۱',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>

<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'فوتر ۲',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>

<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'فوتر ۳',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>

<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'فوتر ۴',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>


<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'بخش خدمات',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>


<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'راهکارها',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>


<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
		'name' => 'باکس پنج',
		'before_widget' => '',
		'after_widget' => '',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));	
	
?>

<?php
function custom_page_title( $title ){
    $return = $title;

    // You can check what the current post is via $wp_query->post
    global $wp_query;
    if( isset($wp_query->post) ){
        $id = $wp_query->post->ID;
        $post_title = $wp_query->post->post_title;
        // etc

        $return = $post_title;
    }

    // Or just outright change the title
    $return = 'میهن وبسایت';

    return $return;
}
add_filter('wp_title', 'custom_page_title', 20);
?>

<?php add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-lightbox' );
}
?>

<?php // Enable support for custom logo.
	add_theme_support( 'custom-logo' );
?>