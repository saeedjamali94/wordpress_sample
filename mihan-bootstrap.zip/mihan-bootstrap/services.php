
<?php /* Template Name: خدمات */ ?>



<!DOCTYPE html>
<html>
<head>
    <title><?php  wp_title(); ?></title>   
<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(); ?>/images/favicon.ico" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/style.css" />
<link rel="manifest" href="/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="theme-color" content="#004444">    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script charset="UTF-8" src="//cdn.sendpulse.com/js/push/5135e942f80fad538f0f0222f2f194a3_0.js" async></script>
<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <script>
        //(function (h, o, t, j, a, r) {
        //    h.hj = h.hj || function () { (h.hj.q = h.hj.q || []).push(arguments) };
        //    h._hjSettings = { hjid: 284607, hjsv: 5 };
        //    a = o.getElementsByTagName('head')[0];
        //    r = o.createElement('script'); r.async = 1;
        //    r.src = t + h._hjSettings.hjid + j + h._hjSettings.hjsv;
        //    a.appendChild(r);
        //})(window, document, '//static.hotjar.com/c/hotjar-', '.js?sv=');
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date(); a = s.createElement(o),
                m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)
        })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');
        ga('create', 'UA-87778530-2', 'auto');
        ga('send', 'pageview');
    </script>

</head>
<body id="homepage">
    

<script>
    var notify = {
    text : 'مطلب دلخواه',
    link : 'لینک تلگرام',
    cookieKey : '_notify'
    };
</script>


<header id="site-header">
    <section id="top-header" class="wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
        <div class="container">
            <div class="row">
                <div class="col-xs-2 hidden-xs hidden-sm col-sm-7 col-md-8 pull-right">
                    <div id="top-header-link-items-wrap" class="dropdown">
                        <button id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="ion-navicon"></span>
                        </button>
                        <ul id="top-header-link-items" class="dropdown-menu" aria-labelledby="dLabel">
                            <li class="default_false"><a  href="<?php bloginfo('template_url'); ?>/%d8%ae%d8%af%d9%85%d8%a7%d8%aa/">خدمات</a></li>
                            <li class="default_false"><a  href="<?php bloginfo('template_url'); ?>/%d9%85%d9%82%d8%a7%d9%84%d8%a7%d8%aa/">مقالات</a></li>
                            <li class="default_false"><a  href="<?php bloginfo('template_url'); ?>/%d8%a7%d8%ae%d8%a8%d8%a7%d8%b1/">اخبار</a></li>
                            <li class="default_false"><a  href="<?php bloginfo('template_url'); ?>/%d8%af%d8%b1%d8%a8%d8%a7%d8%b1%d9%87-%d9%85%d8%a7/">درباره ما</a></li>
                            <li class="default_false"><a  href="<?php bloginfo('template_url'); ?>/%d8%aa%d9%85%d8%a7%d8%b3-%d8%a8%d8%a7-%d9%85%d8%a7/">تماس با ما</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-4">
                    <div id="top-header-left">
                        <div class="links">
                            <a data-identity="register-link" target="_blank" href="#">عضویت</a>
                            <a data-identity="login-link" target="_blank" href="#">ورود</a>
                            <span data-identity="tel">
                                <i class="ion-ios-telephone-outline"></i>&nbsp;
                                ۰۲۱-۸۶۰۸۶۸۶۴
                            </span>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <section id="mid-header" class="wow slideInDown" data-wow-delay="0s" data-wow-duration=".6s">
        <div class="container">
            <div class="row">
                <div>
                   <button id="responsiveNavMenu" type="button" class="visible-xs visible-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <a href="#" class="menu-mobile" style="display:block !important;padding:5px !important;padding-top:0px !important;"><i class="fas fa-bars"></i> منوی اصلی</a>
                    </button>
                    <span id="header-logo"><a href=""><img src="<?php bloginfo('template_url'); ?>/images/b08dd6379f8348ebb8396a1e67438d94.png" width="150" height="40" alt="وب 24" class="aaa" /></a></span>

<!--  mobile menu -->					
<nav id="top-nav-menu">        
<div class="menu-container ccc">
    <div class="menu">
	<ul class="show-on-mobile">
      <?php

$defaults = array(
	'theme_location'  => '',
	'menu'            => 'topmenu',
	'container'       => '',
	'container_class' => '',
	'container_id'    => '',
	'menu_class'      => '',
	'menu_id'         => '',
	'echo'            => true,
	'fallback_cb'     => 'wp_page_menu',
	'before'          => '',
	'after'           => '',
	'link_before'     => '',
	'link_after'      => '',
	'items_wrap'      => '<ul id="menu-main-menu" class="menu">%3$s</ul>',
	'depth'           => 0,
	'walker'          => ''
);

wp_nav_menu( $defaults );

?>
</ul>

    </div>
</div>
</nav>
<!--  mobile menu -->
<nav id="top-nav-menu">                      
<div class="menu-container bbb">
    <div class="menu" id="desktop_menu">
      <?php

$defaults = array(
	'theme_location'  => '',
	'menu'            => 'topmenu',
	'container'       => '',
	'container_class' => '',
	'container_id'    => '',
	'menu_class'      => '',
	'menu_id'         => '',
	'echo'            => true,
	'fallback_cb'     => 'wp_page_menu',
	'before'          => '',
	'after'           => '',
	'link_before'     => '',
	'link_after'      => '',
	'items_wrap'      => '<ul id="menu-main-menu" class="menu">%3$s</ul>',
	'depth'           => 0,
	'walker'          => ''
);

wp_nav_menu( $defaults );

?>

    </div>
</div>
                    </nav>
                </div>
                <span id="header-left-menu-slogan" class="rtl hidden-sm hidden-xs"><a target="_blank" href="#">لذت کار با وب 24 را تجربه کنید</a></span>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <section id="header-wallpaper" style="background-image:url('<?php bloginfo('template_url'); ?>/images/services.jpg')">
        <div class="main-slogan-wrap">
            <strong id="main-slogan" class="rtl wow fadeInDown" data-wow-duration="1.5s" data-wow-delay="1s">صفحه خدمات</strong>
        </div>
        
       
    </section>
</header>
<!-- header -->

    
<div class="container" style="padding:50px;font-family:IRANsansweb;min-height:500px;direction:rtl;">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

	<?php the_title(); ?></h1>  
        <div class="entry">
            <?php the_content(); ?>
        </div><!-- entry -->
	<?php endwhile; ?>
	<?php endif; ?>
</div>





    
<!-- footer -->
<footer>
    <section class="footer-row1">
        <div class="container">
            <div class="row">
                <div data-identity="quickaccess" class="col-xs-12 col-sm-6 col-md-3" style="text-align:right;">
                    <!-- quick access -->
                    <strong class="section-title-inline"><span>دسترسی سریع</span></strong>
						<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('فوتر ۱')) : ?><?php endif; ?>
                    <!-- // quick access -->
                </div>
                <div data-identity="services" class="col-xs-12 col-sm-6 col-md-3" style="text-align:right;">
                    <strong class="section-title-inline"><span>خدمات وب 24</span></strong>
                    
						<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('فوتر ۲')) : ?><?php endif; ?>
                </div>
                <div data-identity="contactus" class="col-xs-12 col-sm-6 col-md-3" style="text-align:right;">
                    <!-- contact summary -->
                    <strong class="section-title-inline"><span>تماس با ما</span></strong>
						<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('فوتر ۳')) : ?><?php endif; ?>
                    <!-- // contact summary -->
                </div>                <!-- map -->
                <div data-identity="map" class="col-xs-12 col-sm-6 col-md-3" style="text-align:right;">
                    <strong class="section-title-inline"><span>وب 24 در شبکه های اجتماعی</span></strong>
						<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('فوتر ۴')) : ?><?php endif; ?>
                </div>
                <!-- // map -->
                </div>
        </div>
    </section>
    
    <section class="footer-copyright">
        <div class="container">
            <!-- copyright -->
            
    <div class="row">
        <div class="col-xs-12 col-sm-9 col-md-10 pull-right">
                
            <p>متن کپی رایت</p>
        </div>
        <div class="col-xs-12 col-sm-3 col-md-2">
            لوگوی شرکت
        </div>
    </div>

            <!-- // copyright -->
        </div>
    </section>
</footer>
<!-- // copyright -->
    
    <script src="/template/web24.js?v=O_BQHh86k-g7hE-VH81HyXrQljcETXyVG1HDKrHGaPc1"></script>


    
<div id="web24Modal" tabindex="-1" class="modal fade" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <strong class="modal-title"></strong>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p class="text-center loader"><img src="<?php bloginfo('template_url'); ?>/images/spinner.gif" /></p>
            </div>
        </div>
    </div>
</div>
<div id="scrollToUp">
    <a href="#"><i class="ion-chevron-up"></i></a>
</div>
<script>
	$('#responsiveNavMenu').click(function() {
		var x = $("#top-nav-menu .menu-container .menu .show-on-mobile").css("display");
		if (x=='block') {
			$('#top-nav-menu .menu-container .menu .show-on-mobile').css('display','none');
		}else if (x=='none') {
			$('#top-nav-menu .menu-container .menu .show-on-mobile').css('display','block');
		}
		
	})
</script>    
</body>
</html>