


<!DOCTYPE html>
<html>
<head>
    <title><?php  wp_title(); ?></title>   
<link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(); ?>/images/favicon.ico" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/style.css" />

<meta name="theme-color" content="#004444"> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>   
<!--bootstrap import-->
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<!-- Popper JS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</head>
<body id="homepage">
    



<header id="site-header">
    <section id="top-header" class="wow fadeIn" data-wow-delay=".3s" data-wow-duration="1s">
        <div class="container">
            <div class="row">
                <div class="col-xs-2 hidden-xs hidden-sm col-sm-7 col-md-8 pull-right">
                    <div id="top-header-link-items-wrap" class="dropdown">
                        <button id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="ion-navicon"></span>
                        </button>
                        <ul id="top-header-link-items" class="dropdown-menu" aria-labelledby="dLabel">
                            <li class="default_false"><a  href="http://mihanwebsite.com/%d8%ae%d8%af%d9%85%d8%a7%d8%aa/">خدمات</a></li>
                            <li class="default_false"><a  href="http://mihanwebsite.com/%d9%85%d9%82%d8%a7%d9%84%d8%a7%d8%aa/">مقالات</a></li>
                            <li class="default_false"><a  href="http://mihanwebsite.com/%d8%a7%d8%ae%d8%a8%d8%a7%d8%b1/">اخبار</a></li>
                            <li class="default_false"><a  href="http://mihanwebsite.com/%d8%af%d8%b1%d8%a8%d8%a7%d8%b1%d9%87-%d9%85%d8%a7/">درباره ما</a></li>
                            <li class="default_false"><a  href="http://mihanwebsite.com/%d8%aa%d9%85%d8%a7%d8%b3-%d8%a8%d8%a7-%d9%85%d8%a7/">تماس با ما</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-4">
                    <div id="top-header-left">
                        <div class="links">
                            <a data-identity="register-link" target="_blank" href="#">عضویت</a>
                            <a data-identity="login-link" target="_blank" href="#">ورود</a>
                            <span data-identity="tel">
                                <i class="ion-ios-telephone-outline"></i>&nbsp;
                                ۰۲۱-۸۶۰۸۶۸۶۴
                            </span>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <section id="mid-header" class="wow slideInDown" data-wow-delay="0s" data-wow-duration=".6s">
        <div class="container">
            <div class="row">
                <div>
                    <button id="responsiveNavMenu" type="button" class="visible-xs visible-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <a href="#" class="menu-mobile" style="display:block !important;padding:5px !important;padding-top:0px !important;"><i class="fas fa-bars"></i> منوی اصلی</a>
                    </button>
                    <span id="header-logo"><a href=""><img src="<?php bloginfo('template_url'); ?>/images/b08dd6379f8348ebb8396a1e67438d94.png" width="150" height="40" alt="میهن وبسایت" class="zzz" /></a></span>
<!--  mobile menu -->					
<nav id="top-nav-menu">        
<div class="menu-container">
    <div class="menu">
	<ul class="show-on-mobile">
      <?php

$defaults = array(
	'theme_location'  => '',
	'menu'            => 'topmenu',
	'container'       => '',
	'container_class' => '',
	'container_id'    => '',
	'menu_class'      => '',
	'menu_id'         => '',
	'echo'            => true,
	'fallback_cb'     => 'wp_page_menu',
	'before'          => '',
	'after'           => '',
	'link_before'     => '',
	'link_after'      => '',
	'items_wrap'      => '<ul id="menu-main-menu" class="menu">%3$s</ul>',
	'depth'           => 0,
	'walker'          => ''
);

wp_nav_menu( $defaults );

?>
</ul>

    </div>
</div>
</nav>
<!--  mobile menu -->

<!--  desktop menu -->					
<nav id="top-nav-menu">
<div class="menu-container">
    <div class="menu" id="desktop_menu">
      <?php

$defaults = array(
	'theme_location'  => '',
	'menu'            => 'topmenu',
	'container'       => '',
	'container_class' => '',
	'container_id'    => '',
	'menu_class'      => '',
	'menu_id'         => '',
	'echo'            => true,
	'fallback_cb'     => 'wp_page_menu',
	'before'          => '',
	'after'           => '',
	'link_before'     => '',
	'link_after'      => '',
	'items_wrap'      => '<ul id="menu-main-menu" class="menu">%3$s</ul>',
	'depth'           => 0,
	'walker'          => ''
);

wp_nav_menu( $defaults );

?>

    </div>
</div>
</nav>
<!--  desktop menu -->
                </div>
                <span id="header-left-menu-slogan" class="rtl hidden-sm hidden-xs"><a target="_blank" href="#">لذت کار را با میهن وبسایت تجربه کنید</a></span>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <section id="header-wallpaper" style="background-image:url('<?php bloginfo('template_url'); ?>/images/779f74d22738499880d85083140b3881.jpg')">
        <div class="main-slogan-wrap">
            <strong id="main-slogan" class="rtl wow fadeInDown" data-wow-duration="1.5s" data-wow-delay="1s">طراح موفقیت کسب و کار</strong>
        </div>
        <div class="links-wrap">
            <div class="links wow slideInUp" data-wow-delay=".6s">
                <a class="wow fadeInRight" data-wow-delay=".5s" href="<?php bloginfo('template_url'); ?>/%d8%b7%d8%b1%d8%a7%d8%ad%db%8c-%d8%b3%d8%a7%db%8c%d8%aa-%d8%ad%d8%b1%d9%81%d9%87-%d8%a7%db%8c/">طراحی سایت حرفه ای</a>
                                <a class="wow fadeInRight" data-wow-delay=".7s" href="<?php bloginfo('template_url'); ?>/%d8%b3%d8%a6%d9%88-%d9%88-%d8%a8%d9%87%db%8c%d9%86%d9%87-%d8%b3%d8%a7%d8%b2%db%8c-%d8%b3%d8%a7%db%8c%d8%aa-2/">سئو و بهینه سازی سایت</a>
                                <a class="wow fadeInRight" data-wow-delay=".9s" href="<?php bloginfo('template_url'); ?>/%d8%b7%d8%b1%d8%a7%d8%ad%db%8c-%d9%84%d9%be%d9%84%db%8c%da%a9%db%8c%d8%b4%d9%86-%d9%85%d9%88%d8%a8%d8%a7%db%8c%d9%84/">طراحی اپلیکیشن موبایل</a>
                                <a class="wow fadeInRight" data-wow-delay="1.1s" href="<?php bloginfo('template_url'); ?>/%d8%a8%d8%a7%d8%b2%d8%a7%d8%b1%db%8c%d8%a7%d8%a8%db%8c-%d8%a7%db%8c%d9%86%d8%aa%d8%b1%d9%86%d8%aa%db%8c/">مشاوره و بازاریابی اینترنتی</a>
                            </div>
        </div>
        <div class="spec-links-wrap">
            <div class="links wow fadeInDown" data-wow-delay="1.3s" data-wow-duration="1s">
                <a class="wow puffIn" data-wow-delay="1.4s" href="<?php bloginfo('template_url'); ?>/%d9%86%d9%85%d9%88%d9%86%d9%87-%da%a9%d8%a7%d8%b1%d9%87%d8%a7%db%8c-%d8%b7%d8%b1%d8%a7%d8%ad%db%8c-%d8%b3%d8%a7%db%8c%d8%aa-2/">نمونه کارهای طراحی سایت</a>
                                <a class="wow puffIn" data-wow-delay="1.5s" href="<?php bloginfo('template_url'); ?>/%d9%86%d9%85%d9%88%d9%86%d9%87-%da%a9%d8%a7%d8%b1%d9%87%d8%a7%db%8c-%d8%b7%d8%b1%d8%a7%d8%ad%db%8c-%d8%a7%d9%be%d9%84%db%8c%da%a9%db%8c%d8%b4%d9%86/">نمونه کارهای اپلیکیشن موبایل</a>
                                <a class="wow puffIn" data-wow-delay="1.6s" href="<?php bloginfo('template_url'); ?>/%d9%86%d9%85%d9%88%d9%86%d9%87-%da%a9%d8%a7%d8%b1%d9%87%d8%a7%db%8c-%d8%b3%d8%a6%d9%88/">نمونه کارهای سئو و بهینه سازی وب</a>
            </div>
        </div>
    </section>
</header>
<!-- header -->

    





<section id="FourBoxes">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xx-12 col-sm-6 col-md-3 pull-right">
                <div class="box-item">
                    <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('باکس یک')) : ?><?php endif; ?>
                </div>
            </div>
            <div class="col-xs-6 col-xx-12 col-sm-6 col-md-3 pull-right">
                <div class="box-item">
                    <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('باکس دو')) : ?><?php endif; ?>
                </div>
            </div>
            <div class="col-xs-6 col-xx-12 col-sm-6 col-md-3 pull-right">
                <div class="box-item">
                    <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('باکس سه')) : ?><?php endif; ?>
                </div>
            </div>
            <div class="col-xs-6 col-xx-12 col-sm-6 col-md-3 pull-right">
                <div class="box-item">
                    <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('باکس چهار')) : ?><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>



<section id="HomeBox" class="parallax background" style="background-image:url('<?php bloginfo('template_url'); ?>/images/067e8acfc64244a8a65a708c699eb8f4.jpg');position:relative;z-index:0; background-size:100%;" data-img-width="1500" data-img-height="700">
    <div class="container" style="font-family:IRANSansweb !important">
        <div class="web24Scrollbar default" data-theme="light">
            <div style="color:#fff;position:absolute;z-index:1;"><?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('متن اصلی سایت')) : ?><?php endif; ?></div>
        </div>
    </div>
</section>


<section id="Services">
    <div class="container">
        <h3 class="section-title"><span>خدمات</span></h3>
        <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('بخش خدمات')) : ?><?php endif; ?>
    </div>
</section>


<section id="features_advantages" class="mt0 mb0">
    <div class="container">
        <div class="flex-row">
            <div class="col-xs-12 col-sm-6 col-md-6 last-xs">
                


<div id="Web24FeaturesBox">
    <strong class="section-title-inline"><span>ویژگی های میهن وبسایت </span></strong>
    <div class="ContentText">
       <p><?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('باکس رنگی')) : ?><?php endif; ?></p>

    </div>
</div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6">
                


<div id="Web24AdvantagesBox" class="theme-bg contentBody">
    <strong class="section-title-inline"><span>مزایای طراحی سایت با مهین وبسایت</span></strong>
    <div class="ContentText">
        <p><?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('باکس مزایا')) : ?><?php endif; ?></p>

    </div>
</div>
            </div>
        </div>
    </div>
</section>



<section id="web24-business-solution" style="font-family:IRANsansweb;">
    <div class="container">
        <div id="wbs-Inner">
            <strong class="section-title-inline"><span>راهکارهای ما برای توسعه برند شما</span><span data-identity="phone-number">مشاور رایگان:&nbsp;<span class="wbs-phone-num">۰۲۱۸۶۰۸۶۸۶۴</span><i class="spriteimages phone"></i></span></strong>
            <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('راهکارها')) : ?><?php endif; ?>
        </div>
    </div>
</section>
<section id="glance_change" class="mt0 mb0">
    <div class="container">
        <div class="flex-row">
            <div class="col-xs-12 col-sm-6 col-md-6 last-xs">
                




<section id="web24-glance">
    <strong class="section-box-simple">
        میهن وبسایت در یک نگاه
    </strong>
    <div class="wg-boxes">
        <div class="flex-row rtl">
            <div class="col-xs-4 col-xx-12 col-sm wg-box">
                <div class="wg-box-inner">
                    <div class="wg-box-icon">
                        <a href="#">
                            <img src="<?php bloginfo('template_url'); ?>/images/255d77f649614a05b7b87ba8794bb009.png" width="60" height="60" />
                            <p>10+ سال فعالیت</p>
                        </a>
                    </div>
                    <div class="wg-box-link">
                        <a href="#">
                            تاریخچه میهن وبسایت
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-xs-4 col-xx-12 col-sm wg-box">
                <div class="wg-box-inner">
                    <div class="wg-box-icon">
                        <a href="#">
                            <img src="<?php bloginfo('template_url'); ?>/images/9a83a0b9bd9b4882a55c6bec974b426b.png" width="60" height="60" />
                            <p>600+ مشتری</p>
                        </a>
                    </div>
                    <div class="wg-box-link">
                        <a href="#">
                            نظرات مشتریان
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-xs-4 col-xx-12 col-sm wg-box">
                <div class="wg-box-inner">
                    <div class="wg-box-icon">
                        <a href="#">
                            <img src="<?php bloginfo('template_url'); ?>/images/b81cedd5839543958dadbc03c55bd997.png" width="60" height="60" />
                            <p>200+ نمونه موفق</p>
                        </a>
                    </div>
                    <div class="wg-box-link">
                        <a href="#">
                           نمونه کارهای میهن وبسایت
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-6">
                




<section id="ready-for-change" style="color:#fff;font-family:IRANsansweb">
    <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('باکس پنج')) : ?><?php endif; ?>
    <div class="clearfix"></div>
    <div class="rfc-links">
        <div class="rfc-link-items">
            <a href="#" target="_blank" title="تماس با تلگرام">تماس با تلگرام</a>
            <a href="#" title="ثبت سفارش">ثبت سفارش</a>
        </div>
    </div>
</section>
            </div>
        </div>
    </div>
</section>

<section id="article_news">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-xs-12 pull-right">
                <!-- News -->
                



    <strong Class="section-title-underline">
        <span>آخرین مقالات</span>
            
    </strong>
    <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('آخرین مقالات')) : ?><?php endif; ?>
            </div>
        </div>
    </div>
</section>


    

   
    
<!-- footer -->
<footer>
    <section class="footer-row1">
        <div class="container">
            <div class="row">
                <div data-identity="quickaccess" class="col-xs-12 col-sm-6 col-md-3" style="text-align:right;">
                    <!-- quick access -->
                    <strong class="section-title-inline"><span>دسترسی سریع</span></strong>
						<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('فوتر ۱')) : ?><?php endif; ?>
                    <!-- // quick access -->
                </div>
                <div data-identity="services" class="col-xs-12 col-sm-6 col-md-3" style="text-align:right;">
                    <strong class="section-title-inline"><span>خدمات میهن وبسایت</span></strong>
                    
						<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('فوتر ۲')) : ?><?php endif; ?>
                </div>
                <div data-identity="contactus" class="col-xs-12 col-sm-6 col-md-3" style="text-align:right;">
                    <!-- contact summary -->
                    <strong class="section-title-inline"><span>تماس با ما</span></strong>
						<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('فوتر ۳')) : ?><?php endif; ?>
                    <!-- // contact summary -->
                </div>                <!-- map -->
                <div data-identity="map" class="col-xs-12 col-sm-6 col-md-3" style="text-align:right;">
                    <strong class="section-title-inline"><span>میهن وبسایت در شبکه های اجتماعی</span></strong>
						<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('فوتر ۴')) : ?><?php endif; ?>
                </div>
                <!-- // map -->
                </div>
        </div>
    </section>
    
    <section class="footer-copyright">
        <div class="container">
            <!-- copyright -->
            
    <div class="row">
        <div class="col-xs-12 col-sm-9 col-md-10 pull-right">
                
            <p>تمام حقوق نزد شرکت میهن وبسایت محفوظ است</p>
        </div>
        <div class="col-xs-12 col-sm-3 col-md-2">
            
        </div>
    </div>

            <!-- // copyright -->
        </div>
		    <?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Clean_Commerce
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'template-parts/content', 'page' ); ?>

				<?php
					// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
					endif;
				?>

			<?php endwhile; // End of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->



<div style="display:none"><?php get_footer(); ?></div>
    </section>
</footer>
<!-- // copyright -->
    

<script>
	$('#responsiveNavMenu').click(function() {
		var x = $("#top-nav-menu .menu-container .menu .show-on-mobile").css("display");
		if (x=='block') {
			$('#top-nav-menu .menu-container .menu .show-on-mobile').css('display','none');
		}else if (x=='none') {
			$('#top-nav-menu .menu-container .menu .show-on-mobile').css('display','block');
		}
	})
	
</script>
</body>
</html>